import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentAllComponent } from './student-all/student-all.component';
import { StudentCreateComponent } from './student-create/student-create.component';
import { StudentEditComponent } from './student-edit/student-edit.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { WelcomeComponent } from './welcome/welcome.component';
import { CustomerComponent } from './customer/customer.component';
import { OrdersComponent } from './orders/orders.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CardViewComponent } from './card-view/card-view.component';
import { MapViewComponent } from './map-view/map-view.component';
import { ListViewComponent } from './list-view/list-view.component';
import { NewCustomerComponent } from './new-customer/new-customer.component';
import { Card1Component } from './card1/card1.component';
import { Card2Component } from './card2/card2.component';
import { Card3Component } from './card3/card3.component';

const appRoutes: Routes=[
  {path:'Welcome',component:WelcomeComponent},
  {path:'Customer',component:CustomerComponent},
  {path:'Orders',component:OrdersComponent},
  {path:'About',component:AboutComponent},
  {path:'Login',component:LoginComponent},
  {path:'CardView',component:CardViewComponent},
  {path:'Card1',component:Card1Component},
  {path:'Card2',component:Card1Component},
  {path:'Card3',component:Card1Component},
  {path:'ListView',component:ListViewComponent},
  {path:'MapView',component:MapViewComponent},
  {path:'NewCustomer',component:NewCustomerComponent},
  {path: 'all', component: StudentAllComponent},
  {path: 'add', component: StudentCreateComponent},
  {path: 'edit/:id', component: StudentEditComponent}
  
 

  
  
  
  ];


@NgModule({
  declarations: [
    AppComponent,
    StudentAllComponent,
    StudentCreateComponent,
    StudentEditComponent,
    WelcomeComponent,
    CustomerComponent,
    OrdersComponent,
    AboutComponent,
    LoginComponent,
    CardViewComponent,
    MapViewComponent,
    ListViewComponent,
    NewCustomerComponent,
    Card1Component,
    Card2Component,
    Card3Component,
      ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
